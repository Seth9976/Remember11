// 函数: sub_40ff80
// 地址: 0x40ff80
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_a59b24 = *(arg1 + 0x44)
return 0
