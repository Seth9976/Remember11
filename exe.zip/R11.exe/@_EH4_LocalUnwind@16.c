// 函数: @_EH4_LocalUnwind@16
// 地址: 0x48dcc0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return __local_unwind4(arg4, arg1, arg2)
