// 函数: __ehhandler$?_wcrtomb_s_l@@YAHQAHQADI_WQAU_Mbstatet@@QAU__crt_locale_pointers@@@Z
// 地址: 0x49b4cf
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_480cd2(*(arg1 - 0x24) ^ (arg1 + 0xc))
return sub_48212c(0x4acdf8) __tailcall
