// 函数: sub_407020
// 地址: 0x407020
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_4067c0()
sub_448760()
int32_t edx = (&data_4cf1b8)[data_2b603b0]
data_2b68250 = (data_2b603b0 << 4) + 0x4cf1c0
int32_t* eax_3 = data_2b68250
data_2b6824c = edx
sub_447710(eax_3)
sub_442650(data_2b68250, &data_2b6824c)
sub_440f80(data_2b603b8)
sub_440fb0(data_2b603b8, 0, 0)

if (data_c7b7a0(data_2b55e6c) != 0)
    sub_406f80()

sub_405140()
sub_401020(0xff, 0xff, 0xff)
sub_405b70(0xffffffff)
sub_401020(0, 0xff, 0)
sub_441450(data_2b6824c - (&data_4cf1b8)[data_2b603b0], 0x1d4c00)
sub_441430(data_2b603a4)
int32_t var_2c = 0
int32_t var_30 = 0
sub_401020(0x40, 0x40, 0x40)
sub_441440(sub_448340(data_4ca040))
sub_406ee0()
sub_44b670(data_4ca040, 0)
int32_t var_10_1 = 0
sub_44b620(data_2b68250, 2)
data_2b603ac += 1
return 0
