// 函数: ??0_Init_locks@std@@QAE@XZ
// 地址: 0x4973a0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (InterlockedIncrement(0x4ccfa8) == 0)
    for (void* i = &data_c7b4e8; i s< 0xc7b548; i += 0x18)
        sub_49849f(i)

return arg1
