// 函数: sub_402810
// 地址: 0x402810
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

char* eax = *(arg1 + 0x44)
*eax = 1
arg1:2.b = 0xff
arg1:1.b = 0xff
arg1.b = 0xff
arg1:3.b = 0x80
sub_4437c0(&data_4cd170, &arg1, *(eax + 4))
return 0
