// 函数: __SEH_epilog4
// 地址: 0x4851b5
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

TEB* fsbase
fsbase->NtTib.ExceptionList = arg1[-4]
*arg1
*arg1 = __return_addr
