// 函数: sub_406710
// 地址: 0x406710
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (data_2b68248 == 1)
    int32_t var_4_1 = data_2b6823c
    sub_44b870(0xa59590, (data_2b603b0).b)
    
    if (data_2b603b4 == 0)
        data_2b603b0
    
    data_2b68248 = 0

data_2b603a4 += 1
data_2b603a8 += 1
data_2b68244 += 1
sub_401db0()
int32_t var_4_2 = 0
return 0
