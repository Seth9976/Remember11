// 函数: sub_408ff0
// 地址: 0x408ff0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* result = arg1 * 0x4b1ec
*(result + 0x8969f8) = arg2
*(result + 0x8969fa) = arg3
return result
