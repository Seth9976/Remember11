// 函数: sub_406f40
// 地址: 0x406f40
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_2b603b4 = arg1
int32_t var_4 = 0

if (data_2b603b4 != 0)
    int32_t var_8_1 = 0x50
    int32_t var_c_1 = 0
else
    int32_t var_8 = 2
    int32_t var_c = 1

int32_t var_10 = 0
sub_447f20()
sub_405f70()
sub_4063b0()
return sub_447f30(sub_406710) __tailcall
