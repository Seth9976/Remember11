// 函数: __unwindfunclet$??0VirtualProcessor@details@Concurrency@@QAE@XZ$1
// 地址: 0x49ada4
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return sub_47a1e0(*(arg1 - 0x10) + 0x94) __tailcall
