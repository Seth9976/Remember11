// 函数: sub_408fa0
// 地址: 0x408fa0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* result

for (void* i = &data_8969f9; i s< &data_a59581; i += 0x4b1ec)
    int32_t var_c_1 = 0x4b1e4
    void* var_10_1 = i + 7
    *(i - 1) = 0
    *i = 0x80
    *(i + 1) = 0
    *(i + 2) = 0
    result = sub_44fcd0(2)
    *(i + 3) = result

return result
