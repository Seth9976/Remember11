// 函数: sub_40fd40
// 地址: 0x40fd40
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

*(data_e7e648 + 0x1f5d0) = 0
*(data_e7e648 + 0x1f5d4) = 0
int32_t ecx = data_e7e648
int32_t eax_2 = arg1 * 0x50
uint32_t edx_1 = zx.d(*(eax_2 + ecx + 0x20860))
arg1 = edx_1
return sub_40fca0(eax_2 + ecx + 0x20838, edx_1.b) __tailcall
