// 函数: sub_4088d0
// 地址: 0x4088d0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_896934 = data_8969d0
data_89693c = 0x196000
data_896938 = 0x40

if (sub_4072c0(0x90e0, &data_896930) s< 0)
    int32_t i
    
    do
        data_8969a4 += 1
        int32_t j
        
        do
            j = sub_4072c0(0x80f0, &data_896930)
        while (j != 1)
        int32_t ecx_1
        i, ecx_1 = sub_4072c0(0x90e0, &data_896930)
    while (i s< 0)

int32_t i_1

do
    i_1 = sub_4072c0(0x80f0, &data_896930)
while (i_1 != 1)

return i_1
