// 函数: sub_405f70
// 地址: 0x405f70
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_449990(0xa598c0, 0, 0x280, 0x1c0, 2, 0x32, 1)
sub_4494f0(0xa598c0, 0, 0x280, 0x1c0, 0, 0)
sub_4494f0(0xa598e8, 0, 0x280, 0x1c0, 0, 0)
sub_4497c0(&data_a59920, 0, 0x280, 0x1c0, 2, 0x3a)
sub_4497c0(&data_a59a10, 0, 0x280, 0x1c0, 2, 0x3a)
sub_447d90(0xa599a0, 2, 0x6c0, 0x720, 0x280, 0x1c0, 0x10, 0x60, 0x60, 0x80, 0)
sub_447d90(0xa59a90, 2, 0x6c0, 0x720, 0x280, 0x1c0, 0x10, 0x60, 0x60, 0x80, 0)
int32_t edx = data_a59924
int32_t eax_2 = (data_a598f8 & 0xfffffe01) | 1
int32_t ecx_2 = (data_a59920 & 0xfffffe01) | 1
data_a598d0 &= 0xfffffe00
data_a59a10 &= 0xfffffe00
data_a598f8 = eax_2
int32_t eax_3 = data_a59a14
data_a59920 = ecx_2
int32_t ecx_3 = data_a59930
data_a59924 = edx
data_a59a14 = eax_3
int32_t edx_1 = data_a59934
int32_t eax_5 = data_a59a20 & 0xfffffe02
data_a59930 = (ecx_3 & 0xfffffe02) | 2
int32_t ecx_6 = data_a59a24
data_a59934 = edx_1
data_a59a20 = eax_5 | 2
data_a59a24 = ecx_6
data_a599c0 = 0x80000000
data_a599c4 = 0x3f800000
data_a59ab0 = 0x80000000
data_a59ab4 = 0x3f800000
sub_449e70(0xa59590, 0, 0x280, 0x1c0, 2, 0x32, 1)
sub_4494f0(0xa59590, 0, 0x280, 0x1c0, 0, 0)
sub_4494f0(0xa595b8, 0, 0x280, 0x1c0, 0, 0)
sub_4497c0(&data_a595f0, 0, 0x280, 0x1c0, 2, 0x3a)
sub_4497c0(&data_a59760, 0, 0x280, 0x1c0, 2, 0x3a)
sub_447d90(0xa596f0, 2, 0x6c0, 0x720, 0x280, 0x1c0, 0x10, 0x60, 0x60, 0x80, 0)
sub_447d90(0xa59860, 2, 0x6c0, 0x720, 0x280, 0x1c0, 0x10, 0x60, 0x60, 0x80, 0)
data_a595a0 &= 0xfffffe00
int32_t edx_2 = data_a595c8
int32_t ecx_7 = data_a595f4
int32_t eax_8 = data_a595f0 & 0xfffffe01
data_a59760 &= 0xfffffe00
data_a597e0 &= 0xfffffe00
data_a595f0 = eax_8 | 1
int32_t eax_10 = data_a59600
data_a595f4 = ecx_7
data_a59604 = data_a59604
int32_t ecx_9 = data_a59670
data_a595c8 = (edx_2 & 0xfffffe01) | 1
data_a59764 = data_a59764
int32_t edx_6 = data_a59770
data_a59600 = (eax_10 & 0xfffffe02) | 2
data_a59774 = data_a59774
int32_t eax_14 = data_a597e4
data_a59670 = (ecx_9 & 0xfffffe01) | 1
int32_t ecx_12 = data_a59680
data_a597e4 = eax_14
int32_t eax_15 = data_a597f0
data_a59770 = (edx_6 & 0xfffffe02) | 2
data_a59674 = data_a59674
int32_t edx_10 = data_a59684
data_a59680 = (ecx_12 & 0xfffffe02) | 2
int32_t ecx_15 = data_a597f4
data_a59684 = edx_10
data_a597f0 = (eax_15 & 0xfffffe02) | 2
data_a597f4 = ecx_15
sub_449ca0(&data_a59670, 0, 0x280, 0x1c0, 0, 0x3a)
sub_449ca0(&data_a597e0, 0, 0x280, 0x1c0, 0, 0x3a)
int32_t ecx_16 = data_a59680
int32_t edx_11 = data_a59674
data_a59670 |= 0x1ff
data_a597e0 |= 0x1ff
data_a597e4 = data_a597e4
int32_t eax_20 = data_a597f0 & 0xfffffe02
data_a59674 = edx_11
int32_t edx_12 = data_a59684
data_a59680 = (ecx_16 & 0xfffffe02) | 2
int32_t ecx_19 = data_a597f4
int32_t result = eax_20 | 2
data_a59684 = edx_12
data_a597f0 = result
data_a597f4 = ecx_19
data_a59710 = 0x80000000
data_a59880 = 0x80000000
data_a59714 = 0x3f800000
data_a59884 = 0x3f800000
return result
