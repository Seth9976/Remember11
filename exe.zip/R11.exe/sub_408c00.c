// 函数: sub_408c00
// 地址: 0x408c00
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_a59580 = 0x80
data_a59581 = 3
data_a59582 = 0
data_a59586 = 0
data_a5958a = 0
data_a5958c = 0
sub_480cf0(&data_896978, 0, 0x50)
data_896974 = 0xffffffff
data_896970 = 0xffffffff
return 0xffffffff
