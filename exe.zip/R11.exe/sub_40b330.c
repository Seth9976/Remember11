// 函数: sub_40b330
// 地址: 0x40b330
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* ecx_2 = data_e7e648
data_2b603a4 = 0
*(ecx_2 + 0x13220) = 0
*(data_e7e648 + 0x13224) = 0
*(data_e7e648 + 0x13228) = data_2b603a4
void* eax_1 = arg1[0x11]
*(eax_1 + 8) += 2
sub_40a8a0(arg1)
return 0
