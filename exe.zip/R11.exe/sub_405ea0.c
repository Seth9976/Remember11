// 函数: sub_405ea0
// 地址: 0x405ea0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t result = sub_405d00(arg1, arg2, arg3, arg4)

if (sub_405bd0(result) == 0)
    int32_t i
    
    do
        for (void* j = &data_2b697c4; j s< 0x2b6a5fc; j += 0x16c)
            int32_t eax_2 = *j
            
            if (eax_2 != 0)
                int16_t eax_3 = eax_2(j)
                *(j + 0x12) = eax_3
                
                if (eax_3 != 0)
                    *j = 0
        
        i = sub_405bd0(result)
    while (i == 0)

return result
