// 函数: sub_4059d0
// 地址: 0x4059d0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* result = arg1 * 0x208
*(result + 0x2b68268) = 0
return result
