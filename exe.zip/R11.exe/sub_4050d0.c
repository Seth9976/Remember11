// 函数: sub_4050d0
// 地址: 0x4050d0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_4cd109 = arg1
uint32_t result = zx.d(arg1) * 3
data_4cd114 = 0
data_4cd108 = 0
data_4cd118 = 0
data_4cd134 = 0
int32_t ecx = (&data_4af580)[result]
data_4cd110 = arg2
data_4cd168 = &data_4cd108
data_4cd124 = ecx
return result
