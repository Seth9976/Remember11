// 函数: Ordinal_libpng13_1
// 地址: 0x49853a
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return Ordinal_libpng13_1() __tailcall
