// 函数: sub_401020
// 地址: 0x401020
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t temp0 = data_2b6a4fc

if (temp0 s> 0 || (temp0 s>= 0 && data_2b6a4f8 u>= 0x80))
    return 

int32_t eax = sub_448340(data_4ca040)
void* ecx_1 = data_2b6a4f8
*((ecx_1 << 2) + &data_2b6a680) = eax
eax.b = arg2
*(ecx_1 + 0x2b6a600) = arg1
*(ecx_1 + 0x2b6a580) = eax.b
*(ecx_1 + 0x2b6a500) = arg3
data_2b6a4fc = adc.d(data_2b6a4fc, 0, ecx_1 u>= 0xffffffff)
data_2b6a4f8 = ecx_1 + 1
