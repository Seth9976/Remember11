// 函数: sub_401fb0
// 地址: 0x401fb0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t i_1 = arg1
int32_t ecx = arg2

if (i_1 s> 0)
    int32_t eax_2 = data_2b55e84 + 4
    int32_t i
    
    do
        ecx += *eax_2
        eax_2 += 0xc
        i = i_1
        i_1 -= 1
    while (i != 1)

return zx.d(*((ecx u>> 3) + 0x2b5cd71)) u>> (ecx.b & 7) & 1
