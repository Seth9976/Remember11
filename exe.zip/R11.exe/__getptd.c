// 函数: __getptd
// 地址: 0x488e00
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* result = sub_488d89()

if (result == 0)
    sub_482a3f(0x10)

return result
