// 函数: __ehhandler$?_FullAliasWait@_TaskCollection@details@Concurrency@@AAEXPAV123@@Z
// 地址: 0x499fb8
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_480cd2(*(arg1 - 0x2c) ^ (arg1 + 0xc))
return sub_48212c(0x4ab044) __tailcall
