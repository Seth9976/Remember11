// 函数: sub_401990
// 地址: 0x401990
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

*arg1 += arg1
data_2b55e80 = *arg1
arg1[1] += arg1
data_2b55e84 = arg1[1]
arg1[2] += 0x22166a0
int32_t* ecx = arg1[2]
int32_t i

for (i = 0; i s< 0x10000; )
    int32_t edx_1 = *ecx
    
    if (edx_1 == 0)
        break
    
    *ecx = edx_1 + 0x22166a0
    i += 1
    ecx = &ecx[1]

data_2b55e8c = i u>> 1
data_2b55e88 = arg1[2]
arg1[3] += 0x22166a0
int32_t* eax_4 = arg1[3]
int32_t i_1

for (i_1 = 0; i_1 s< 0x10000; )
    int32_t edx_3 = *eax_4
    
    if (edx_3 == 0)
        break
    
    *eax_4 = edx_3 + 0x22166a0
    i_1 += 1
    eax_4 = &eax_4[1]

data_2b55e94 = i_1
data_2b55e90 = arg1[3]
arg1[4] += 0x22166a0
int32_t* eax_6 = arg1[4]
int32_t i_2

for (i_2 = 0; i_2 s< 0x10000; )
    int32_t edx_5 = *eax_6
    
    if (edx_5 == 0)
        break
    
    *eax_6 = edx_5 + 0x22166a0
    i_2 += 1
    eax_6 = &eax_6[1]

data_2b55e9c = i_2
data_2b55e98 = arg1[4]
arg1[5] += 0x22166a0
int32_t* eax_8 = arg1[5]
int32_t i_3

for (i_3 = 0; i_3 s< 0x10000; )
    int32_t edx_7 = *eax_8
    
    if (edx_7 == 0)
        break
    
    *eax_8 = edx_7 + 0x22166a0
    i_3 += 1
    eax_8 = &eax_8[1]

data_2b55ea4 = i_3
data_2b55ea0 = arg1[5]
arg1[6] += 0x22166a0
int32_t* eax_10 = arg1[6]
int32_t i_4

for (i_4 = 0; i_4 s< 0x10000; )
    int32_t edx_9 = *eax_10
    
    if (edx_9 == 0)
        break
    
    *eax_10 = edx_9 + 0x22166a0
    i_4 += 1
    eax_10 = &eax_10[1]

data_2b55eac = i_4
data_2b55ea8 = arg1[6]
arg1[7] += 0x22166a0
int32_t* eax_12 = arg1[7]
int32_t i_5

for (i_5 = 0; i_5 s< 0x10000; )
    int32_t edx_11 = *eax_12
    
    if (edx_11 == 0)
        break
    
    *eax_12 = edx_11 + 0x22166a0
    i_5 += 1
    eax_12 = &eax_12[1]

data_2b55eb4 = i_5
data_2b55eb0 = arg1[7]
arg1[8] += 0x22166a0
int32_t* eax_14 = arg1[8]
int32_t i_6

for (i_6 = 0; i_6 s< 0x10000; )
    int32_t edx_13 = *eax_14
    
    if (edx_13 == 0)
        break
    
    *eax_14 = edx_13 + 0x22166a0
    i_6 += 1
    eax_14 = &eax_14[1]

data_2b55ebc = i_6
data_2b55eb8 = arg1[8]
arg1[9] += 0x22166a0
int32_t* eax_16 = arg1[9]
int32_t i_7

for (i_7 = 0; i_7 s< 0x10000; )
    int32_t edx_15 = *eax_16
    
    if (edx_15 == 0)
        break
    
    *eax_16 = edx_15 + 0x22166a0
    i_7 += 1
    eax_16 = &eax_16[1]

data_2b55ec4 = i_7
data_2b55ec0 = arg1[9]
arg1[0xa] += 0x22166a0
int32_t* eax_18 = arg1[0xa]
int32_t i_8

for (i_8 = 0; i_8 s< 0x10000; )
    int32_t edx_17 = *eax_18
    
    if (edx_17 == 0)
        break
    
    *eax_18 = edx_17 + 0x22166a0
    i_8 += 1
    eax_18 = &eax_18[1]

data_2b55ecc = i_8
data_2b55ec8 = arg1[0xa]
arg1[0xb] += 0x22166a0
int32_t* eax_20 = arg1[0xb]
int32_t i_9

for (i_9 = 0; i_9 s< 0x10000; )
    int32_t edx_19 = *eax_20
    
    if (edx_19 == 0)
        break
    
    *eax_20 = edx_19 + 0x22166a0
    i_9 += 1
    eax_20 = &eax_20[1]

data_2b55ed4 = i_9
data_2b55ed0 = arg1[0xb]
arg1[0xc] += 0x22166a0
int32_t* eax_22 = arg1[0xc]
int32_t i_10

for (i_10 = 0; i_10 s< 0x10000; )
    int32_t edx_21 = *eax_22
    
    if (edx_21 == 0)
        break
    
    *eax_22 = edx_21 + 0x22166a0
    i_10 += 1
    eax_22 = &eax_22[1]

data_2b55edc = i_10
data_2b55ed8 = arg1[0xc]
arg1[0xd] += 0x22166a0
int32_t* eax_24 = arg1[0xd]
int32_t i_11

for (i_11 = 0; i_11 s< 0x10000; )
    int32_t edx_23 = *eax_24
    
    if (edx_23 == 0)
        break
    
    *eax_24 = edx_23 + 0x22166a0
    i_11 += 1
    eax_24 = &eax_24[1]

data_2b55ee4 = i_11
data_2b55ee0 = arg1[0xd]
arg1[0xe] += 0x22166a0
int32_t* eax_26 = arg1[0xe]
int32_t i_12

for (i_12 = 0; i_12 s< 0x10000; )
    int32_t edx_25 = *eax_26
    
    if (edx_25 == 0)
        break
    
    *eax_26 = edx_25 + 0x22166a0
    i_12 += 1
    eax_26 = &eax_26[1]

data_2b55ef8 = i_12
data_2b55ef0 = arg1[0xe]
arg1[0xf] += arg1
data_2b55ef4 = arg1[0xf]
arg1[0x10] += arg1
data_2b55efc = arg1[0x10]
arg1[0x11] += arg1
data_2b55f00 = arg1[0x11]
arg1[0x12] += 0x22166a0
int32_t* ecx_1 = arg1[0x12]
int32_t i_13

for (i_13 = 0; i_13 s< 0x10000; )
    int32_t edx_27 = *ecx_1
    
    if (edx_27 == 0)
        break
    
    *ecx_1 = edx_27 + 0x22166a0
    i_13 += 1
    ecx_1 = &ecx_1[1]

data_2b55f08 = i_13
data_2b55f04 = arg1[0x12]
arg1[0x13] += arg1
data_2b5670c = arg1[0x13]
arg1[0x14] += arg1
data_2b56710 = arg1[0x14]
arg1[0x15] += arg1
data_2b58718 = arg1[0x15]
arg1[0x16] += arg1
data_2b5a720 = arg1[0x16]
arg1[0x17] += arg1
data_2b5a724 = arg1[0x17]
arg1[0x18] += arg1
data_2b5a72c = arg1[0x18]
arg1[0x19] += arg1
data_2b5a734 = arg1[0x19]
arg1[0x1a] += 0x22166a0
int32_t* eax_39 = arg1[0x1a]
int32_t i_14

for (i_14 = 0; i_14 s< 0x10000; )
    int32_t edx_29 = *eax_39
    
    if (edx_29 == 0)
        break
    
    *eax_39 = edx_29 + 0x22166a0
    i_14 += 1
    eax_39 = &eax_39[1]

data_2b5a740 = i_14
data_2b5a73c = arg1[0x1a]
arg1[0x1c] += arg1
data_2b5a748 = arg1[0x1c]
arg1[0x1b] += arg1
data_2b5a744 = arg1[0x1b]
arg1[0x1d] += arg1
data_2b5a84c = arg1[0x1d]
arg1[0x1e] += 0x22166a0
int32_t* eax_44 = arg1[0x1e]
int32_t i_15

for (i_15 = 0; i_15 s< 0x10000; )
    int32_t edx_31 = *eax_44
    
    if (edx_31 == 0)
        break
    
    *eax_44 = edx_31 + 0x22166a0
    i_15 += 1
    eax_44 = &eax_44[1]

data_2b5a854 = i_15
data_2b5a850 = arg1[0x1e]
sub_4016e0()
sub_401730()
sub_401790()
sub_480cf0(0x2b58720, 0, 0x1000)
sub_401810(arg1)
sub_401860(arg1)
sub_4018f0(arg1)
return sub_401940() __tailcall
