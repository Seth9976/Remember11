// 函数: sub_409b40
// 地址: 0x409b40
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int16_t* esi = *data_c7bbcc
int32_t eax = sub_448f10(esi, 1)
sub_4479d0(esi, 0, 0x67, 0, arg1, arg2)
sub_448880(data_c7bbc8, arg2, esi)
int32_t* result = data_c7bbcc
*result += eax << 4
return result
