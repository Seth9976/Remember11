// 函数: sub_409b20
// 地址: 0x409b20
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t var_4 = 0
int32_t var_8 = 0
data_2b603b0
return sub_450c30(0x207e680, 0)
