// 函数: sub_402310
// 地址: 0x402310
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_401620()
sub_480cf0(&data_2b5a860, 0, 0x1bc)
sub_4149f0()
data_2b5a92e = *(data_2b55e80 + 2)
data_2b55e64 = 1
return 1
