// 函数: sub_403fc0
// 地址: 0x403fc0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t var_8 = 0
int32_t var_4 = 0
char var_a = 0x80
char var_b = 0x80
char var_c = 0x80
sub_442e20()
data_c7bbe4 = zx.d(arg2)
data_c7bbe0 = 3
sub_444110(*data_c7bbc0 + 0x58, &var_8, &var_c, *(arg1 + 4))
sub_442c30(*data_c7bbc0 + 0x58, *(arg1 + 4))
return sub_442f40()
