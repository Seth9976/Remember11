// 函数: sub_40ab10
// 地址: 0x40ab10
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

char const* const var_8 = "no cmd err!\n"
void* eax = arg1[0x11]
char* ecx = *(eax + 8)
*(eax + 8) = *((zx.d(*ecx) << 2) + &data_4b0750) + ecx
sub_40a8a0(arg1)
return 0
