// 函数: sub_40e2d0
// 地址: 0x40e2d0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* ecx
ecx.w = *(*(arg1[0x11] + 8) + 2)
*(data_e7e648 + 0x28a4) = ecx.w
*(data_e7e648 + 0x28a6) = 0
void* ecx_2 = arg1[0x11]
*(ecx_2 + 8) += 4
sub_40a8a0(arg1)
return 0
