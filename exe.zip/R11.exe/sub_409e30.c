// 函数: sub_409e30
// 地址: 0x409e30
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (*(arg1 + 0x54) != 0)
    int32_t ecx_2 = data_2b603ac & 0x80000003
    bool cond:0_1 = ecx_2 != 0
    
    if (ecx_2 s< 0)
        cond:0_1 = ((ecx_2 - 1) | 0xfffffffc) != 0xffffffff
    
    if (not(cond:0_1))
        int32_t ecx_6 = *(arg1 + 4)
        
        if (ecx_6 != 0)
            *(arg1 + 4) = ecx_6 - 1
        
        int32_t ecx_8 = *(arg1 + 8)
        
        if (ecx_8 != 0)
            *(arg1 + 8) = ecx_8 - 1
        
        int32_t ecx_10 = *(arg1 + 0xc)
        
        if (ecx_10 != 0)
            *(arg1 + 0xc) = ecx_10 - 1
        
        int32_t ecx_12 = *(arg1 + 0x10)
        
        if (ecx_12 != 0)
            *(arg1 + 0x10) = ecx_12 - 1
        
        int32_t ecx_14 = *(arg1 + 0x14)
        
        if (ecx_14 != 0)
            *(arg1 + 0x14) = ecx_14 - 1
        
        int32_t ecx_16 = *(arg1 + 0x18)
        
        if (ecx_16 != 0)
            *(arg1 + 0x18) = ecx_16 - 1
        
        int32_t ecx_18 = *(arg1 + 0x1c)
        
        if (ecx_18 != 0)
            *(arg1 + 0x1c) = ecx_18 - 1
        
        int32_t ecx_20 = *(arg1 + 0x20)
        
        if (ecx_20 != 0)
            *(arg1 + 0x20) = ecx_20 - 1
        
        int32_t ecx_22 = *(arg1 + 0x24)
        
        if (ecx_22 != 0)
            *(arg1 + 0x24) = ecx_22 - 1
        
        int32_t ecx_24 = *(arg1 + 0x28)
        
        if (ecx_24 != 0)
            *(arg1 + 0x28) = ecx_24 - 1

return arg1
