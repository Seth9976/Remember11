// 函数: sub_40b8b0
// 地址: 0x40b8b0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax = arg1[0x11]
void* ecx = *(eax + 8)
sub_41c410(zx.d(*(ecx + 2)) + *(eax + 0xc), zx.d(*(ecx + 1)))
void* eax_1 = arg1[0x11]
*(eax_1 + 8) += 4
sub_40a8a0(arg1)
return 0
