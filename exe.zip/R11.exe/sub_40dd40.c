// 函数: sub_40dd40
// 地址: 0x40dd40
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* ecx_1 = *(arg1[0x11] + 8)
void* esi = data_e7e648
*(esi + 0x2094e) = *(esi + 0x2094d)
ecx_1.b = *(ecx_1 + 1)
*(data_e7e648 + 0x2094d) = ecx_1.b
void* ecx_2 = arg1[0x11]
*(ecx_2 + 8) += 2
sub_40a8a0(arg1)
return 0
