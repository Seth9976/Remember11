// 函数: sub_4085a0
// 地址: 0x4085a0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void var_28
sub_447f60(1, 0x8010, 0x980, nullptr, var_28)
sub_447f60(1, 0x8010, 0xa80, nullptr)
sub_447f60(1, 0x8010, 0x981, nullptr)
sub_447f60(1, 0x8010, 0xa81, nullptr)
sub_447f60(1, 0x8010, 0xb80, nullptr)
sub_447f60(1, 0x8010, 0xc80, nullptr)
sub_447f60(1, 0x8010, 0xb81, nullptr)
sub_447f60(1, 0x8010, 0xc81, nullptr)
sub_447f60(1, 0x8050, 0x1d00, 0x1dffff)
sub_447f60(1, 0x8050, 0x1d01, 0x1fffff)
int16_t var_20 = 0xd600
int16_t var_1e = 0xd600
int16_t var_c = 0xd800
int16_t var_a = 0xd800
int32_t var_8 = 0x32
int32_t var_4 = 0x32
int32_t var_1c = 0
int32_t var_18 = 0
void* var_24 = 4
void* var_10 = 8
sub_447f60(1, 0x8130, nullptr, &var_28)
sub_447f60(1, 0x8150, nullptr, nullptr, var_24)
void var_14
sub_447f60(1, 0x8130, 1, &var_14)
sub_447f60(1, 0x8150, 1, nullptr, var_10)
sub_447f60(1, 0x8070, 2, 1)
sub_447f60(1, 0x8070, 3, 1)
sub_447f60(1, 0x8010, 0x800, 0xfc0)
sub_447f60(1, 0x8010, 0x801, 0xfcc)
sub_447f60(1, 0x8010, 0x980, 0x3fff)
sub_447f60(1, 0x8010, 0xa80, 0x3fff)
sub_447f60(1, 0x8010, 0x981, 0x3fff)
sub_447f60(1, 0x8010, 0xa81, 0x3fff)
sub_447f60(1, 0x8010, 0xb80, 0x3fff)
sub_447f60(1, 0x8010, 0xc80, 0x3fff)
sub_447f60(1, 0x8010, 0xb81, 0x3fff)
sub_447f60(1, 0x8010, 0xc81, 0x3fff)
return 1
