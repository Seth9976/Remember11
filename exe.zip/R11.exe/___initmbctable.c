// 函数: ___initmbctable
// 地址: 0x487b51
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (data_2b6b9f0 == 0)
    sub_4879b7(0xfffffffd)
    data_2b6b9f0 = 1

return 0
