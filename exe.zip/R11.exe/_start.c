// 函数: _start
// 地址: 0x481bdf
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_489f10()
return sub_4819ff() __tailcall
