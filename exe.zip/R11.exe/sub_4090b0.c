// 函数: sub_4090b0
// 地址: 0x4090b0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return zx.d(*(arg1 * 0x4b1ec + &data_8969f9))
