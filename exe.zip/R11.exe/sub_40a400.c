// 函数: sub_40a400
// 地址: 0x40a400
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

*(data_e7e648 + 0xb4458) = 0xf0
*(data_e7e648 + 0xb445c) = arg1
*(data_e7e648 + 0xb4460) = arg2
return arg2
