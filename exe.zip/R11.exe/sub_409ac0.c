// 函数: sub_409ac0
// 地址: 0x409ac0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

arg1[1] = 0
*arg1 = 1
arg1[5] = arg2
int32_t result = sub_446c50(sub_409730, arg1, arg3, 2)
arg1[2] = result
return result
