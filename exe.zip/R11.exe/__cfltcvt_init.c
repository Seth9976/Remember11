// 函数: __cfltcvt_init
// 地址: 0x480d6a
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_4cbf28 = __cfltcvt
data_4cbf2c = sub_4856ed
data_4cbf30 = sub_4856ab
data_4cbf34 = sub_4856df
data_4cbf38 = sub_485655
data_4cbf3c = __cfltcvt
data_4cbf40 = __cfltcvt_l
data_4cbf44 = sub_48566b
data_4cbf48 = sub_4855d5
data_4cbf4c = sub_485564
return __cfltcvt
