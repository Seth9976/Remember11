// 函数: sub_407990
// 地址: 0x407990
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t eax
int32_t edx
edx:eax = sx.q(arg1)
data_885518 = eax
int32_t eax_1 = arg2
data_88551c = edx
data_885520 = 0
data_885524 = 0

if (eax_1 s<= 0)
    eax_1 = 1

int32_t result
int32_t edx_1
edx_1:result = sx.q(eax_1)
data_885528 = result
data_88552c = edx_1
return result
