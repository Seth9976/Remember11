// 函数: $LN17
// 地址: 0x482cba
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (*(arg1 + 0x10) != 0)
    __unlock(8)
