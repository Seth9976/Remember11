// 函数: sub_405050
// 地址: 0x405050
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_402350(0x280, 0x1e0)
data_4cd109 = 0
data_4cd110 = 0
data_4cd10a = 0
data_4cd11c = 0
data_4cd11f = 0
data_4cd11e = 0
data_4cd11d = 0
data_4cd114 = 0
data_4cd108 = 0
data_4cd118 = 0
data_4cd134 = 0
void* result = data_4af580
data_4cd10c = 0x1e
data_4cd120 = 0x80
data_4cd168 = &data_4cd108
data_4cd124 = result
return result
