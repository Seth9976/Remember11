// 函数: sub_402290
// 地址: 0x402290
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_405e30(7, 6, &data_2196680, &data_e7e660)
uint32_t result

for (void* i = nullptr; i u< 0x18; i += 8)
    result = sub_4427e0(*(i + 0x4af568) * 0x2c + *data_c7bbc0, 0x900, 0, 
        &(&data_2196680)[(*((*(i + 0x4af56c) << 2) + &data_2196684)
            + (((data_2196680 << 2) + 0x13) u>> 4)) * 4])

return result
