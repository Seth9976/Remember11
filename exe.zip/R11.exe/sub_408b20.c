// 函数: sub_408b20
// 地址: 0x408b20
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t ecx = data_8969d4
int32_t edx = data_8969d0
int32_t var_4 = 0
data_896940 = data_8969d8
data_896930 = ecx
data_896934 = edx
data_896938 = 0x80000
data_89693c = 0x6000
data_896978 = sub_4072c0(0x9150, &data_896930)
data_89697c = sub_4072c0(0xc0, 0x3010)
data_896980 = sub_4072c0(0xd0, 0x100)
data_896984 = sub_4072c0(0x8140, data_8969d8)
return sub_4072c0(0x8130, 0xb)
