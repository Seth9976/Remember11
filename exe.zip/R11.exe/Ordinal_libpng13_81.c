// 函数: Ordinal_libpng13_81
// 地址: 0x498546
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return Ordinal_libpng13_81() __tailcall
