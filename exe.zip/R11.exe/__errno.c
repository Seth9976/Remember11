// 函数: __errno
// 地址: 0x485065
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax_2 = sub_488d89()

if (eax_2 != 0)
    return eax_2 + 8

return 0x4cbf20
