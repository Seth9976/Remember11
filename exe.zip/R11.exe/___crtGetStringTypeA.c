// 函数: ___crtGetStringTypeA
// 地址: 0x494cb9
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void var_14
sub_481612(&var_14, arg1)
BOOL result = sub_494a95(&var_14, arg2, arg3, arg4, arg5, arg6, arg7)
char var_8
void* var_c

if (var_8 != 0)
    *(var_c + 0x70) &= 0xfffffffd
return result
