// 函数: sub_4024b0
// 地址: 0x4024b0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t* eax = &arg1[7]
arg1 = eax
jump(*eax)
