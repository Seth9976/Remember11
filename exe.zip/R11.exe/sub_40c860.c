// 函数: sub_40c860
// 地址: 0x40c860
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* esi = *(arg1[0x11] + 8)
sub_416b50(zx.d(*(esi + 1)))
sub_418740(zx.d(*(esi + 1)), zx.d(*(esi + 2)), *(data_e7e648 + 0xbf0c0))
void* eax_2 = arg1[0x11]
*(eax_2 + 8) += 4
sub_40a8a0(arg1)
return 0
