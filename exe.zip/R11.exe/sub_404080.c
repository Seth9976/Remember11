// 函数: sub_404080
// 地址: 0x404080
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

char* esi = *(arg1 + 0x44)
*esi = 1
sub_403fc0(esi, 0x80)
return 0
