// 函数: sub_405f10
// 地址: 0x405f10
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t var_4_2 = 0
char const* const var_8 = "cdrom0:\MODULES\IOPRP310.IMG;1"
int32_t var_4_1 = 0
return sub_45e4e0() __tailcall
