// 函数: ?Clone@PdbMemStream@@UAGJPAPAUIStream@@@Z
// 地址: 0x47cca0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return 0x80004001
