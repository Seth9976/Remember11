// 函数: sub_401000
// 地址: 0x401000
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_2b6a4f8 = 0
data_2b6a4fc = 0
data_2b6a4f0 = 0
data_2b6a4f4 = 0
return 0
