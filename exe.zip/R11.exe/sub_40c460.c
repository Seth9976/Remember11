// 函数: sub_40c460
// 地址: 0x40c460
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* edi = *(arg1[0x11] + 8)

if (sub_41d1d0() != 0)
    *(arg1 + 0xe) = 0
    *(arg1 + 0xd) = 0
    return 0

sub_415460()
sub_414db0(*(edi + 2), sx.w(*(data_e7e648 + 0x1d74a)))
void* ecx_1 = data_e7e648
void* eax_3 = arg1[0x11]
*(eax_3 + 8) = zx.d(*(((sx.d(*(ecx_1 + 0x1d74a)) + 0x1d76) << 4) + ecx_1)) + *(eax_3 + 0xc)
sub_41d330()
sub_41d380()
sub_40a8a0(arg1)
return 0
