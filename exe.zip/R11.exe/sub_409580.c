// 函数: sub_409580
// 地址: 0x409580
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return sub_44fc50(*(arg1 i* 0x4b1ec + 0x8969fc)) __tailcall
