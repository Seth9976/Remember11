// 函数: __ehhandler$?shortsort@@YAXPAD0IP6AHPBX1@Z@Z
// 地址: 0x499ae0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_480cd2(*(arg1 - 0x14) ^ (arg1 + 0xc))
return sub_48212c(0x4aab00) __tailcall
