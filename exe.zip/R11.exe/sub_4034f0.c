// 函数: sub_4034f0
// 地址: 0x4034f0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

char* eax = *(arg1 + 0x44)
int32_t ecx = *(eax + 4)
*eax = 1
sub_4437c0(&data_4cd170, &eax[0x15], ecx)
return 0
