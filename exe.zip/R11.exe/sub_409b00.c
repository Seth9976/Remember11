// 函数: sub_409b00
// 地址: 0x409b00
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_2b60390 = 0
data_2b60394 = 0
data_2b60398 = 0
data_2b6039c = 0
return 0
