// 函数: ov_pcm_total
// 地址: 0x49857c
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return ov_pcm_total() __tailcall
