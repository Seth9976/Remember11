// 函数: sub_402450
// 地址: 0x402450
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

*(arg1 + 0x15) = arg2
*(arg1 + 0x14) = 0
*(arg1 + 0x18) = 0x80
*(arg1 + 0x16) = arg3
*(arg1 + 0x17) = arg4
return arg1
