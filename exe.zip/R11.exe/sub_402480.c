// 函数: sub_402480
// 地址: 0x402480
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

*(arg1 + 4) = arg2
return arg2
