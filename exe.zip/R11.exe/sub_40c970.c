// 函数: sub_40c970
// 地址: 0x40c970
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* esi = *(arg1[0x11] + 8)
int32_t eax_1 = sub_414cf0(sx.d(*(esi + 4)))
int32_t eax_2 = sub_414cf0(sx.d(*(esi + 2)))
sub_4168c0(zx.d(*(esi + 1)), eax_2, eax_1)
void* eax_4 = arg1[0x11]
*(eax_4 + 8) += 6
sub_40a8a0(arg1)
return 0
