// 函数: sub_406fd0
// 地址: 0x406fd0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_406910()
sub_406b80()
data_2b55e68 = 2
int32_t var_14 = 0
int32_t var_18 = 0
data_2b55e6c = sub_446d10(&data_4af018, 0x2b537e0, 0x80, 0)
return sub_44b670(data_4ca040, 0)
