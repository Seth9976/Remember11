// 函数: sub_407960
// 地址: 0x407960
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_885518 = 0
data_88551c = 0
data_885520 = 0
data_885524 = 0
data_885528 = 8
data_88552c = 0
return 0
