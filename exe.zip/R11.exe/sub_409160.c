// 函数: sub_409160
// 地址: 0x409160
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax = arg1 * 0x4b1ec

if (*(eax + 0x8969fb) != 0)
    int32_t eax_2 = sub_44f850(*(eax + 0x8969fc))
    
    if (eax_2 != 0 && (eax_2 s<= 4 || eax_2 s> 6))
        return 1

return 0
