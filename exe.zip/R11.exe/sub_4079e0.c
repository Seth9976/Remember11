// 函数: sub_4079e0
// 地址: 0x4079e0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (*(data_886f1c + 4) != arg1)
    void* const __saved_esi_2 = &data_49e1ac
else if ((&data_2243af0)[arg1] != 6)
    char const* const __saved_esi_1 = "      *\n"
else
    char const* const var_8_1 = "      "
    
    for (int32_t i = 0; i s< 5; i += 1)
        if (*(data_886f1c + (arg1 << 2) + 8) != i)
            char const* const var_8_3 = "    "
        else
            char const* const var_8_2 = "*   "
    
    void* const var_8_4 = &data_49e1ac

int32_t __saved_esi_3 = (&data_4af9a8)[zx.d((&data_2243af0)[arg1])]
void* const var_8_5 = arg2
char const* const var_c = "%s:%s"

if ((&data_2243af0)[arg1] != 6)
    arg2 = &data_49e1ac
    return sub_47b730() __tailcall

uint32_t result = zx.d(*((arg1 << 2) + &data_2243ac2))
uint32_t __saved_esi_4 = zx.d(*((arg1 << 2) + &data_2243ac3))
uint32_t result_1 = result
uint32_t var_c_1 = zx.d(*((arg1 << 2) + &data_2243ac1))
uint32_t var_10 = zx.d(*((arg1 << 2) + &data_2243ac0))
char const* const var_14 = "(%03d.%03d.%03d.%03d)\n"
return result
