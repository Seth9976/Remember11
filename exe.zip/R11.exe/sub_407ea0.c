// 函数: sub_407ea0
// 地址: 0x407ea0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

char const* const __saved_ebx = "pfs0:"
int32_t __saved_esi = 0
int32_t var_10 = 0
int32_t var_14 = 0
char const* const var_18 = "hdd0:r11,fpasswd,rpasswd,1G,PFS"
char const* const var_1c = "pfs0:"
int32_t var_20 = 0xfffff
int32_t var_24 = 0x202
char const* const var_28 = "pfs0:/setup.bin"
sub_447c00()
int32_t ebx = 0

for (void* i = &data_2243ac0; i s< 0x2243ae8; )
    int32_t var_10_1 = 1
    void* var_14_1 = &(&data_2243af0)[ebx]
    int32_t var_18_1 = 0
    sub_447c40()
    int32_t var_1c_1 = 4
    void* i_1 = i
    int32_t var_24_1 = 0
    sub_447c40()
    i += 4
    ebx += 1

int32_t var_10_2 = 0
sub_447c20()
char const* const var_14_2 = "pfs0:"
return 0
