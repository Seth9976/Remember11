// 函数: sub_4091c0
// 地址: 0x4091c0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* edi_1 = arg1 * 0x4b1ec

if (*(edi_1 + 0x8969fb) != 0 && sub_44f850(*(edi_1 + 0x8969fc)) - 2 u<= 3)
    int32_t eax_5
    int32_t edx_1
    edx_1:eax_5 = mulu.dp.d(0x10624dd3, sub_44fb60(*(edi_1 + 0x8969fc)))
    return divu.dp.d(0:(sub_44fb10(*(edi_1 + 0x8969fc)) * 0x30), edx_1 u>> 6)

return 0xffffffff
