// 函数: sub_40cb80
// 地址: 0x40cb80
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax_1 = *(arg1[0x11] + 8)

if (sub_418460(sx.d(*(eax_1 + 1)), sx.d(*(eax_1 + 2))) != 0)
    *(arg1 + 0xe) = 0
    *(arg1 + 0xd) = 0
    return 0

void* eax_3 = arg1[0x11]
*(eax_3 + 8) += 4
sub_40a8a0(arg1)
return 0
