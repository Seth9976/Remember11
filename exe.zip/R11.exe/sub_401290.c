// 函数: sub_401290
// 地址: 0x401290
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_2b55e64 = 1
return 1
