// 函数: sub_40f050
// 地址: 0x40f050
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* esi = *(arg1[0x11] + 8)
int32_t eax_1 = sub_414cf0(zx.d(*(esi + 6)))
int32_t eax_2 = sub_414cf0(zx.d(*(esi + 4)))
sub_40f970(sub_414cf0(zx.d(*(esi + 2))), eax_2, eax_1)
void* eax_5 = arg1[0x11]
*(eax_5 + 8) += 8
sub_40a8a0(arg1)
return 0
