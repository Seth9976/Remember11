// 函数: ov_seekable
// 地址: 0x498588
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return ov_seekable() __tailcall
