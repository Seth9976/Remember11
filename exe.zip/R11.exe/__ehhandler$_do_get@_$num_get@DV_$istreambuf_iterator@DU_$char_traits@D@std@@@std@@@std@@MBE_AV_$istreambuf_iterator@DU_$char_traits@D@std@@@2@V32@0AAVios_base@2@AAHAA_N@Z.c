// 函数: __ehhandler$?do_get@?$num_get@DV?$istreambuf_iterator@DU?$char_traits@D@std@@@std@@@std@@MBE?AV?$istreambuf_iterator@DU?$char_traits@D@std@@@2@V32@0AAVios_base@2@AAHAA_N@Z
// 地址: 0x49b47a
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_480cd2(*(arg1 - 0x8c) ^ (arg1 + 0xc))
sub_480cd2(*(arg1 - 4) ^ (arg1 + 0xc))
return sub_48212c(0x4acda0) __tailcall
