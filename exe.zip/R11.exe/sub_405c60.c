// 函数: sub_405c60
// 地址: 0x405c60
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return *(arg1 * 0x16c + 0x2b69814)
