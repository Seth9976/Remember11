// 函数: __ehhandler$___std_fs_get_file_id@8
// 地址: 0x4998a0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_480cd2(*(arg1 - 0x20) ^ (arg1 + 0xc))
return sub_48212c(0x4aa768) __tailcall
