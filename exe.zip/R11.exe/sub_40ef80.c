// 函数: sub_40ef80
// 地址: 0x40ef80
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax_1 = *(arg1[0x11] + 8)
*(data_e7e648 + 0x20945) = *(eax_1 + 1)
*(data_e7e648 + 0x20946) = *(eax_1 + 2)
*(data_e7e648 + 0x20947) = *(eax_1 + 3)
*(data_e7e648 + 0x20948) = *(eax_1 + 4)
eax_1.b = *(eax_1 + 5)
*(data_e7e648 + 0x20949) = eax_1.b
sub_420950()
void* eax_2 = arg1[0x11]
*(eax_2 + 8) += 6
sub_40a8a0(arg1)
return 0
