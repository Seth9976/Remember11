// 函数: Ordinal_libpng13_8
// 地址: 0x498570
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return Ordinal_libpng13_8() __tailcall
