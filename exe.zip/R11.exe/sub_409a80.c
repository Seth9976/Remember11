// 函数: sub_409a80
// 地址: 0x409a80
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

arg2[1] = arg1
*arg2 = 0
arg2[5] = &arg2[6]
int32_t result = sub_446c50(sub_409730, arg2, arg3 - 0x1c, 2)
arg2[2] = result
return result
