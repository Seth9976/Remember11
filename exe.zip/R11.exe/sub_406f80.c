// 函数: sub_406f80
// 地址: 0x406f80
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_446d40(data_2b55e6c)
sub_405e20()
int32_t eax = data_2b55e64
int32_t ecx = data_2b55e68
data_2b55e68 = eax
data_2b55e60 = ecx
int32_t result = sub_446d10(&(&data_4af000)[eax * 3], 0x2b537e0, 0x80, 0)
data_2b55e6c = result
return result
