// 函数: __NLG_Call
// 地址: 0x492224
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t eax
return eax()
