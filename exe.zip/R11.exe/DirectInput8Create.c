// 函数: DirectInput8Create
// 地址: 0x498510
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return DirectInput8Create(hinst, dwVersion, riidltf, ppvOut, punkOuter) __tailcall
