// 函数: sub_40a3f0
// 地址: 0x40a3f0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* result = data_e7e648
*(result + 0xb4458) = 0
return result
