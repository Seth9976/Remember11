// 函数: __invalid_parameter_noinfo
// 地址: 0x481d3f
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return sub_481d1b(0, 0, 0, 0, 0)
