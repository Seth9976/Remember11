// 函数: sub_405170
// 地址: 0x405170
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (*(arg1 + 0x15c) == 0)
    *(arg1 + 0x15c) = (*(arg1 + 0x168) + *(arg1 + 0x160) + 0xf) u>> 4 << 4
