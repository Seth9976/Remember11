// 函数: sub_40a1e0
// 地址: 0x40a1e0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t eax_1 = data_e7e648
int32_t esi_1 = arg1 * 0x104
int32_t edi = *(esi_1 + eax_1 + 0x1f6cc)
char* result = sub_480cf0(esi_1 + eax_1 + 0x1f678, 0, 0x58)
*(esi_1 + data_e7e648 + 0x1f6cc) = edi
return result
