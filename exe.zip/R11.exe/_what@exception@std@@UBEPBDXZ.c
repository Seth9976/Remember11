// 函数: ?what@exception@std@@UBEPBDXZ
// 地址: 0x481f0a
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

char const* const result = *(arg1 + 4)

if (result != 0)
    return result

return "Unknown exception"
