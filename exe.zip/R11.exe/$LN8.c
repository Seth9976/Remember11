// 函数: $LN8
// 地址: 0x480ca9
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return sub_4839fe(1, 0x4cbb00)
