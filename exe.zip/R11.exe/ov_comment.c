// 函数: ov_comment
// 地址: 0x49858e
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return ov_comment() __tailcall
