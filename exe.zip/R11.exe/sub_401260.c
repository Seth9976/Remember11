// 函数: sub_401260
// 地址: 0x401260
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t var_4 = 0
int32_t eax = sub_44c8d0()

if (eax != 3 && eax != 4)
    return 0

return 2
