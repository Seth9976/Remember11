// 函数: sub_408cb0
// 地址: 0x408cb0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t result
result.b = 0
data_a5958f = 0
data_a5958d = 0x80
data_a5958e = 0
return result
