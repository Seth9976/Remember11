// 函数: sub_40b9f0
// 地址: 0x40b9f0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_41c680(zx.d(*(*(arg1[0x11] + 8) + 1)))
void* eax_1 = arg1[0x11]
*(eax_1 + 8) += 2
sub_40a8a0(arg1)
return 0
