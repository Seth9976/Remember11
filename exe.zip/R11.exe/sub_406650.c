// 函数: sub_406650
// 地址: 0x406650
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void var_104
int32_t eax_1 = __security_cookie ^ &var_104
int32_t var_110 = *arg1
sub_480b92(&var_104, "cdrom0:\MODULES\%s;1")
int32_t var_11c = arg1[2]
int32_t var_120 = arg1[1]
void* var_124 = &var_104
arg1[3] = 0
int32_t var_110_2 = *arg1
int32_t var_114_2 = arg1[3]
char const* const var_118_2 = "load module %3d:'%s'\n"
sub_480cd2(eax_1 ^ &var_104)
return 0
