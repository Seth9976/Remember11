// 函数: sub_40b880
// 地址: 0x40b880
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax_1 = *(arg1[0x11] + 8)
sub_41c790(sx.d(*(eax_1 + 2)), sx.d(*(eax_1 + 4)))
void* eax_2 = arg1[0x11]
*(eax_2 + 8) += 6
sub_40a8a0(arg1)
return 0
