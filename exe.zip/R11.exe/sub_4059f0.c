// 函数: sub_4059f0
// 地址: 0x4059f0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

char* result = arg2
char* esi_1 = arg1 * 0x208 + 0x2b68270 - result
char i

do
    i = *result
    *(esi_1 + result) = i
    result = &result[1]
while (i != 0)
*(arg1 * 0x208 + 0x2b6826c) = arg1
*(arg1 * 0x208 + 0x2b68268) = 1
return result
