// 函数: sub_405150
// 地址: 0x405150
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return sub_480cf0(&data_2b68260, 0, 0x2290)
