// 函数: sub_4076c0
// 地址: 0x4076c0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t var_8 = 0xffffffff
int32_t var_c = *(arg1 + 0x7e38)
int32_t var_10 = 0x87a518
int32_t var_14 = 0x87a4d8
sub_450910()
char const* const var_8_2 = "sceInetAbort() done.\n"
return 0
