// 函数: sub_407270
// 地址: 0x407270
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_4481d0(0x879018, 0x12346, 0)

while (data_87903c == 0)
    sub_4481d0(0x879018, 0x12346, 0)

return 1
