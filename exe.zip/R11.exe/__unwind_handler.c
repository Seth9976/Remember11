// 函数: __unwind_handler
// 地址: 0x492110
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if ((*(arg1 + 4) & 6) == 0)
    return 1

sub_480cd2(*(arg4 - 4) ^ arg4)
*(arg4 + 0x10)
__local_unwind2(*(arg4 + 0x24), *(arg4 + 0x28))
*arg3 = arg2
return 3
