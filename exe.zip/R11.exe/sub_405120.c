// 函数: sub_405120
// 地址: 0x405120
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return zx.d(data_4cd109)
