// 函数: __cexit
// 地址: 0x482cf1
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return sub_482bed(0, 0, 1)
