// 函数: _tidy_global
// 地址: 0x49745c
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t var_8 = arg1
sub_4973f8(&var_8, 0)
sub_497440(&data_c7b550)
data_c7b550 = 0
return sub_497419(&var_8)
