// 函数: sub_401350
// 地址: 0x401350
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_408f30(0xffff)
sub_409010(0, 0xffff)
sub_409010(1, 0xffff)
sub_409010(2, 0xffff)
sub_409010(3, 0xffff)
sub_409010(4, 0xffff)
sub_409010(5, 0xffff)
sub_409010(5, 0xffff)
sub_408c50(0xffffffff)
return sub_43c5b0() __tailcall
