// 函数: sub_40b680
// 地址: 0x40b680
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (sub_4148e0() != 0)
    *(arg1 + 0xe) = 0
    *(arg1 + 0xd) = 0
    return 0

void* eax = arg1[0x11]
*(eax + 8) += 2
sub_40a8a0(arg1)
return 0
