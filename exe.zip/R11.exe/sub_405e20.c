// 函数: sub_405e20
// 地址: 0x405e20
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return sub_405d90(0xffffffff)
