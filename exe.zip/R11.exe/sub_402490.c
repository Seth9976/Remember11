// 函数: sub_402490
// 地址: 0x402490
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

*(arg1 + 2) = arg2
return arg2
