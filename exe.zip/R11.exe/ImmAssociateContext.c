// 函数: ImmAssociateContext
// 地址: 0x49851c
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return ImmAssociateContext(param0, param1) __tailcall
