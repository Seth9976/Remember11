// 函数: ??__Ewcout@std@@YAXXZ
// 地址: 0x49c467
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_46a3b0(&data_c7b610, 0xc7b5c0, 0, 1)
return sub_48258e(sub_49cb5c)
