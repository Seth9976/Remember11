// 函数: sub_4090d0
// 地址: 0x4090d0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* esi_1 = arg1 * 0x4b1ec

if (*(esi_1 + 0x8969fb) != 0)
    sub_44fac0(*(esi_1 + 0x8969fc))

*(esi_1 + 0x8969fb) = 0
