// 函数: sub_402220
// 地址: 0x402220
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return *(*(data_2b5a73c + (arg1 << 2)) + (arg2 << 2))
