// 函数: sub_40fd90
// 地址: 0x40fd90
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return *(arg1 * 0x50 + data_e7e648 + 0x20848)
