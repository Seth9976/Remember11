// 函数: sub_406ee0
// 地址: 0x406ee0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_2b68248 = 1
int32_t var_4 = data_2b6823c
int32_t var_8 = 0
int32_t ecx
ecx.b = data_4cf1e0 == 0
data_4cf1e0 = ecx
sub_447f00()

while (data_2b68248 == 1)
    nop

data_2b68244 = 0
int32_t eax_1 = data_2b603b0
int32_t eax_2 = neg.d(eax_1)
data_2b603b0 = sbb.d(eax_2, eax_2, eax_1 != 0) + 1
return sbb.d(eax_2, eax_2, eax_1 != 0) + 1
