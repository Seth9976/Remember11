// 函数: sub_408bc0
// 地址: 0x408bc0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_405e30(7, 1, &data_e7e660, 0xf7e660)
sub_408960(&data_e7e660)
sub_4089d0(&data_e7e660)
void* edi
sub_408a40(edi, &data_e7e660)
return sub_408b20() __tailcall
