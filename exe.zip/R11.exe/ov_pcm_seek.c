// 函数: ov_pcm_seek
// 地址: 0x4985a6
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return ov_pcm_seek() __tailcall
