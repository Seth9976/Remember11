// 函数: @_EH4_CallFilterFunc@8
// 地址: 0x48dc76
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t ecx
return ecx()
