// 函数: sub_405af0
// 地址: 0x405af0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

*(arg2 + 0x11c) = 0
*(arg2 + 0x11e) = 0
*(arg2 + 4) = 0
*(arg2 + 0x150) = arg2
*(arg2 + 0x10c) = sub_44f840
*(arg2 + 0x119) = 1

switch (*arg1)
    case 0
        *(arg2 + 0x10c) = sub_44f840
    case 1
        *(arg2 + 0x10c) = sub_4051a0
    case 2
        *(arg2 + 0x10c) = sub_405440
    case 3
        *(arg2 + 0x10c) = sub_4056f0

return arg2
