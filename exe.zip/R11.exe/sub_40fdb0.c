// 函数: sub_40fdb0
// 地址: 0x40fdb0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t result = arg1 * 0x50
*(result + data_e7e648 + 0x20844) = 1
return result
