// 函数: __NLG_Notify1
// 地址: 0x4921fc
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t var_8 = arg3
data_4cc948 = arg3
data_4cc944 = arg1
data_4cc94c = arg4
int32_t var_c = arg4
int32_t var_10 = arg3
return arg1
