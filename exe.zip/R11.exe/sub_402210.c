// 函数: sub_402210
// 地址: 0x402210
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return zx.d(*(data_2b5a744 + arg1))
