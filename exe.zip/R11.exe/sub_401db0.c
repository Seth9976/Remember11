// 函数: sub_401db0
// 地址: 0x401db0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t eax = data_2b5a94c

if (data_2b603a0 + eax u>= 0x14996ff)
    data_2b5a94c = 0x14996ff
else
    data_2b5a94c = eax + data_2b603a0

int32_t eax_2 = data_2b60328

if (data_2b603a0 + eax_2 u>= 0x14996ff)
    data_2b60328 = 0x14996ff
    return eax_2

int32_t eax_3 = eax_2 + data_2b603a0
data_2b60328 = eax_3
return eax_3
