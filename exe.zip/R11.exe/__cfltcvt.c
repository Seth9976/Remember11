// 函数: __cfltcvt
// 地址: 0x485ff1
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return __cfltcvt_l(arg1, arg2, arg3, arg4, arg5, arg6, nullptr)
