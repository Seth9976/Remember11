// 函数: sub_411440
// 地址: 0x411440
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* result = data_a59b0c + 0x28
int32_t i_1 = 0x64
int32_t i

do
    *(result - 8) = 0xffffffff
    *(result - 4) = 0
    *result = 0
    *(result + 4) = 0
    *(result + 8) = 0
    result += 0x14
    i = i_1
    i_1 -= 1
while (i != 1)
return result
