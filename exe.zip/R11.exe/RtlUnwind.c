// 函数: RtlUnwind
// 地址: 0x4985ac
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return RtlUnwind(TargetFrame, TargetIp, ExceptionRecord, ReturnValue) __tailcall
