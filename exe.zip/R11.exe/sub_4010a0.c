// 函数: sub_4010a0
// 地址: 0x4010a0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_4cd100 = arg1
return arg1
