// 函数: sub_40a650
// 地址: 0x40a650
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

*(data_e7e648 + 0x30b0) = 0xa0
*(data_e7e648 + 0x30c0) = 0xffff
*(data_e7e648 + 0x30bc) = 0xffffffff
*(data_e7e648 + 0x30b8) = 0xffffffff
*(data_e7e648 + 0x3108) = 0xffff
*(data_e7e648 + 0x3104) = 0xffffffff
*(data_e7e648 + 0x3100) = 0xffffffff
*(data_e7e648 + 0x3150) = 0xffff
*(data_e7e648 + 0x314c) = 0xffffffff
*(data_e7e648 + 0x3148) = 0xffffffff
*(data_e7e648 + 0x3198) = 0xffff
*(data_e7e648 + 0x3194) = 0xffffffff
*(data_e7e648 + 0x3190) = 0xffffffff
*(data_e7e648 + 0x31e0) = 0xffff
*(data_e7e648 + 0x31dc) = 0xffffffff
*(data_e7e648 + 0x31d8) = 0xffffffff
sub_41a5a0(data_e7e648 + 0x13238)
sub_41cdb0(data_e7e648 + 0x1d744)
sub_4146f0()
sub_41c9c0()
sub_41c700(0)
sub_41cdc0()
sub_418380()
sub_412f60()
sub_40fc60()
sub_420730()
sub_420940()
sub_41d5e0()
sub_41d740()
return sub_41dc70() __tailcall
