// 函数: sub_401680
// 地址: 0x401680
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_480cf0(&data_2b5aa20, 0, 0x590c)
sub_480cf0(0x2b5aaf1, 0xff, 0x80)
data_2b5cf18 = 0
sub_401620()
return sub_4012a0() __tailcall
