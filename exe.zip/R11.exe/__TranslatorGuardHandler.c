// 函数: __TranslatorGuardHandler
// 地址: 0x482267
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t var_8 = arg3
sub_480cd2(*(arg5 + 8) ^ arg5)

if ((arg4->ExceptionFlags & 0x66) != 0)
    *(arg5 + 0x24) = 1
    return 1

sub_48b0ae(arg4, *(arg5 + 0x10), arg6, nullptr, *(arg5 + 0xc), *(arg5 + 0x14), *(arg5 + 0x18), 1)

if (*(arg5 + 0x24) == 0)
    sub_4820da(arg5, arg4)

int32_t var_10_2 = 0
sub_482192(0x123, &var_8, 0, 0, 0, 0)
*(arg5 + 0x1c)
*(arg5 + 0x20)
jump(var_8)
