// 函数: __ehhandler$?_Init@?$_Mpunct@G@std@@IAEXABV_Locinfo@2@_N@Z
// 地址: 0x499969
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_480cd2(*(arg1 - 0x54) ^ (arg1 + 0xc))
sub_480cd2(*(arg1 - 8) ^ (arg1 + 0xc))
return sub_48212c(0x4aa900) __tailcall
