// 函数: sub_404b60
// 地址: 0x404b60
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t var_4 = arg3
int32_t edx = *(arg4 + 4)
var_4 = *(arg4 + 0x15)
arg3.b = 0x80
arg3.b = 0x80 - arg5.b
var_4:3.b = arg3.b
sub_4437c0(&data_4cd170, &var_4, edx)
*(arg4 + 4)
int32_t result
int80_t st0
st0, result = sub_404aa0(arg5, nullptr, fconvert.s(float.t(arg5) * fconvert.t(0.0234375f)))
return result
