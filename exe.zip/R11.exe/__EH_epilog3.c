// 函数: __EH_epilog3
// 地址: 0x4920bf
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

TEB* fsbase
fsbase->NtTib.ExceptionList = arg1[-3]
*arg1
*arg1 = __return_addr
