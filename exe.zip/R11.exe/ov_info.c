// 函数: ov_info
// 地址: 0x498582
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return ov_info() __tailcall
