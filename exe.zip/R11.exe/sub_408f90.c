// 函数: sub_408f90
// 地址: 0x408f90
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return sub_446f90(*(arg1 + 8)) __tailcall
