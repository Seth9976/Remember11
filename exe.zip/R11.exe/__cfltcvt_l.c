// 函数: __cfltcvt_l
// 地址: 0x485f6b
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (arg4 == 0x65 || arg4 == 0x45)
    return sub_485868(arg1, arg2, arg3, arg5, arg6.b, arg7)

if (arg4 == 0x66)
    return sub_485dba(arg1, arg2, arg3, arg5, arg7)

if (arg4 != 0x61 && arg4 != 0x41)
    return sub_485e73(arg1, arg2, arg3, arg5, arg6.b, arg7)

return sub_485954(arg1, arg2, arg3, arg5, arg6, arg7)
