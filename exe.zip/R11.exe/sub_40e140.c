// 函数: sub_40e140
// 地址: 0x40e140
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_40a840(sx.d(*(*(*(arg1 + 0x44) + 8) + 1)))
return 1
