// 函数: sub_4023e0
// 地址: 0x4023e0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

arg1[1] = arg2
*(arg1 + 8) = arg3
*(arg1 + 0xc) = 0
*arg1 = 0
*(arg1 + 0x10) = 0
*(arg1 + 0x2c) = 0
*(arg1 + 0x60) = arg1
*(arg1 + 0x1c) = (&data_4af580)[zx.d(arg2) * 3]
return arg1
