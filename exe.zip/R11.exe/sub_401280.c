// 函数: sub_401280
// 地址: 0x401280
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return sub_44c890()
