// 函数: __NLG_Notify
// 地址: 0x492205
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_4cc948 = arg3
data_4cc944 = arg1
data_4cc94c = arg2
int32_t var_c = arg2
int32_t var_10 = arg3
return arg1
