// 函数: Ordinal_libpng13_7
// 地址: 0x498528
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return Ordinal_libpng13_7() __tailcall
