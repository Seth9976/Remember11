// 函数: ___iob_func
// 地址: 0x483887
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return 0x4cbae0
