// 函数: sub_40dd80
// 地址: 0x40dd80
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax_3 = data_e7e648
int32_t var_8 = *(eax_3 + 0xbf0c0)
sub_41d7a0(zx.d(*(*(arg1[0x11] + 8) + 1)), *(eax_3 + 0xbf0be))
void* eax_1 = arg1[0x11]
*(eax_1 + 8) += 2
sub_40a8a0(arg1)
return 0
