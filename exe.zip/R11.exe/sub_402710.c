// 函数: sub_402710
// 地址: 0x402710
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

**(arg1 + 0x44) = 1
return 0
