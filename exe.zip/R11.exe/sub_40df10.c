// 函数: sub_40df10
// 地址: 0x40df10
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* edx = *(arg1[0x11] + 8)
uint32_t eax_1 = zx.d(*(edx + 1))
edx.w = *(edx + 2)
*(data_e7e648 + (eax_1 + 0x3426) * 0xa) = edx.w
void* eax_4 = arg1[0x11]
*(eax_4 + 8) += 4
sub_40a8a0(arg1)
return 0
