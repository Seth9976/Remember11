// 函数: sub_405130
// 地址: 0x405130
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return zx.d(data_4cd108)
