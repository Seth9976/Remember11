// 函数: sub_407670
// 地址: 0x407670
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t var_8 = 0xffffffff
int32_t var_c = *(arg1 + 0x7e38)
int32_t var_10 = 0x87a518
int32_t var_14 = 0x87a4d8
sub_450950()
char const* const var_8_2 = "sceInetClose() done.\n"
return 0
