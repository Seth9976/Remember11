// 函数: sub_405140
// 地址: 0x405140
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return data_4cd124(&data_4cd124)
