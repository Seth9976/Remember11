// 函数: sub_40dd10
// 地址: 0x40dd10
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (sub_41d690() != 0)
    *(arg1 + 0xe) = 0
    *(arg1 + 0xd) = 0
    return 0

void* eax = arg1[0x11]
*(eax + 8) += 2
sub_40a8a0(arg1)
return 0
