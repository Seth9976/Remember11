// 函数: sub_4012a0
// 地址: 0x4012a0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

char ecx = data_4af32c
char edx = data_4af31c
data_2b5cf02 = data_4af340
char eax = data_4af358
data_2b5cf03 = ecx
data_2b5cf05 = eax
data_2b5cf04 = edx
data_2b5cf01 = 0
data_2b5cf06 = 0
data_2b5cf07 = 0
data_2b5cf08 = 0
data_2b5cf09 = 0
data_2b5cf0a = 0
data_2b5cf0b = 2
data_2b5cf0c = 1
data_2b5cf0d = 1
data_2b5cf0e = 0
data_2b5cf0f = 0
data_2b5cf12 = 1
data_2b5cf10 = 0
data_2b5cf13 = 0
data_2b5cf11 = 1
data_2b5cf1a = 1
data_2b5cf14 = 0
data_2b5cf15 = 0
data_2b5cf16 = 1
data_2b5cf17 = 0x80
data_2b5cf19 = 0
data_2b5aa70 = 0
return 0
