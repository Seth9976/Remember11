// 函数: sub_40f000
// 地址: 0x40f000
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* edi = *(arg1[0x11] + 8)
int32_t eax_1 = sub_414cf0(zx.d(*(edi + 4)))
sub_40a400(sub_414cf0(zx.d(*(edi + 2))), eax_1)
void* eax_3 = arg1[0x11]
*(eax_3 + 8) += 6
sub_40a8a0(arg1)
return 0
