// 函数: sub_409100
// 地址: 0x409100
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* esi_1 = arg1 * 0x4b1ec

if (*(esi_1 + 0x8969fb) != 0)
    sub_44fac0(*(esi_1 + 0x8969fc))

uint32_t edx = zx.d(*(esi_1 + 0x8969f8))
void* eax_2 = *(esi_1 + 0x8969fc)
*(esi_1 + 0x8969fb) = 1
sub_44f930(eax_2, edx, arg2)
return sub_409010(arg1, 0xffff)
