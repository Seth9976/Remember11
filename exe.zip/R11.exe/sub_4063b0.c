// 函数: sub_4063b0
// 地址: 0x4063b0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_448860(0x4cf1c0, 0x4cf1e8, 0x20)
sub_448860(0x4cf1d0, 0x6a3ff8, 0x20)
data_4cf1b8 = 0x4cf3f8
data_4cf1bc = 0x6a4208
sub_447710(0x4cf1c0)
sub_447710(0x4cf1d0)
sub_447700(1)
return sub_4476f0(0)
