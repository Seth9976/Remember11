// 函数: sub_40aeb0
// 地址: 0x40aeb0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_480ea0(*(arg1[0x11] + 0xc), *(data_e7e648 + 0xbf0c0), 0x10000)
void* eax_1 = data_e7e648
*(eax_1 + 0x30b0) = *(eax_1 + 0xbf0be)
void* eax_2 = arg1[0x11]
*(eax_2 + 8) = *(eax_2 + 0xc)
sub_40a8a0(arg1)
return 0
