// 函数: sub_40a8e0
// 地址: 0x40a8e0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_414c40(0xb, data_e7e648 + 0x20992, 2)
sub_414c40(0xa, data_e7e648 + 0x20974, 2)
sub_414c40(9, data_e7e648 + 0x2094c, 2)
sub_414c40(8, data_e7e648 + 0x1f5dc, 2)
sub_414c40(7, data_e7e648 + 0x1d744, 2)
sub_414c40(6, data_e7e648 + 0x13238, 2)
sub_414c40(4, data_e7e648 + 0x20928, 2)
sub_414c40(5, data_e7e648 + 0x20934, 2)
sub_414c40(2, data_e7e648 + 0x20828, 2)
sub_414c40(3, data_e7e648 + 0x20838, 2)
*(data_e7e648 + 0x30b0) = data_2b5a92e
sub_414960(0, data_2b5a92e)
void* eax_8 = data_e7e648
sub_480ea0(eax_8 + 0x3220, *(eax_8 + 0xbf0c0), 0x10000)
void* eax_10 = data_e7e648
sub_40a790(0, eax_10 + 0x3220, zx.d(data_2b5a930))
int32_t* eax_13 = sub_446760(*(eax_10 + 0x30b8))
sub_40a8a0(eax_13)
*(eax_13 + 0xd) = 3
*(data_e7e648 + 0x30b2) = data_2b5a92e
*(data_e7e648 + 0x30b4) = data_2b5a930
*(eax_10 + 0x30c8) = data_2b5a950
void* eax_14
eax_14.w = data_2b5a954
*(eax_10 + 0x30ca) = eax_14.w
*(eax_10 + 0x30cc) = data_2b5a956
return sub_414c40(1, data_e7e648 + 0x285c, 2)
