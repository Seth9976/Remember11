// 函数: Ordinal_DSOUND_11
// 地址: 0x498516
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return Ordinal_DSOUND_11() __tailcall
