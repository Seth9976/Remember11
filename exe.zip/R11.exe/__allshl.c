// 函数: __allshl
// 地址: 0x4813a0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (arg3 u>= 0x40)
    return 0

if (arg3 u>= 0x20)
    return 0

return arg1 << arg3
