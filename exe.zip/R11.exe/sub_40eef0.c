// 函数: sub_40eef0
// 地址: 0x40eef0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (sub_4024a0(data_e7e648 + 0xb4180) != 1)
    void* ecx_1 = data_e7e648
    
    if (*(ecx_1 + 0x289c) != 1)
        *(arg1 + 0xe) = 0
        *(arg1 + 0xd) = 0
        return 0
    
    uint32_t eax_2 = zx.d(*(ecx_1 + 0xb417e))
    char var_8_1
    
    if (eax_2.b s< 0)
        if (*((eax_2 & 0x7f) * 0xc + &data_4b0980) != 0)
            var_8_1 = 0x21
        else
            var_8_1 = 0x13
    else
        var_8_1 = 0
    
    sub_4023e0(ecx_1 + 0xb4180, var_8_1, 1)

void* eax_4 = arg1[0x11]
*(eax_4 + 8) += 2
sub_40a8a0(arg1)
return 0
