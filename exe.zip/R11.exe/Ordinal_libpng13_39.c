// 函数: Ordinal_libpng13_39
// 地址: 0x498522
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return Ordinal_libpng13_39() __tailcall
