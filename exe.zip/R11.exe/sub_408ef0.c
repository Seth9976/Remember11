// 函数: sub_408ef0
// 地址: 0x408ef0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if (data_a5958f != 0)
    data_8969a8 = sub_4072c0(0x8020, 0)
    data_8969ac = sub_4072c0(0x8161, 0)

data_a5958f = 0
