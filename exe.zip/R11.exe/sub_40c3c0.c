// 函数: sub_40c3c0
// 地址: 0x40c3c0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax = arg1[0x11]
sub_41d310(zx.d(*(*(eax + 8) + 2)) + *(eax + 0xc))
void* eax_1 = arg1[0x11]
*(eax_1 + 8) += 4
sub_40a8a0(arg1)
return 0
