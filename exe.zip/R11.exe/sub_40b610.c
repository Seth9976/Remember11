// 函数: sub_40b610
// 地址: 0x40b610
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_414db0(*(*(arg1[0x11] + 8) + 2), arg1.w)
void* eax_1 = arg1[0x11]
*(eax_1 + 8) += 4
sub_40a8a0(arg1)
return 0
