// 函数: Ordinal_libpng13_136
// 地址: 0x49854c
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return Ordinal_libpng13_136() __tailcall
