// 函数: sub_406410
// 地址: 0x406410
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_447f60(1, 0x8000, nullptr, arg2, arg1)
int128_t* esi = nullptr

for (void* i = 0x1fffff; i s> 0x1bffff; )
    sub_447f60(1, 0x8010, esi | 0x980, nullptr)
    sub_447f60(1, 0x8010, esi | 0xa80, nullptr)
    sub_447f60(1, 0x8050, esi | 0x1d00, i)
    int16_t var_c_1 = 0
    int16_t var_a_1 = 0
    void* var_10_1 = 5
    void var_14
    sub_447f60(1, 0x8130, esi, &var_14)
    sub_447f60(1, 0x8150, esi, nullptr, var_10_1)
    sub_447f60(1, 0x8070, esi | 2, 1)
    sub_447f60(1, 0x8010, esi | 0xb80, 0x3fff)
    sub_447f60(1, 0x8010, esi | 0xc80, 0x3fff)
    i -= 0x20000
    esi += 1

sub_447f60(1, 0x8050, 0x1d00, 0x1dffff)
sub_447f60(1, 0x8050, 0x1d01, 0x1fffff)
data_4cf1ac = 0xd600
data_4cf1ae = 0xd600
data_4cf198 = 0xd800
data_4cf19a = 0xd800
data_4cf1b0 = 0
data_4cf1b4 = 0
data_4cf1a8 = 4
data_4cf19c = 0x32
data_4cf1a0 = 0x32
data_4cf194 = 8
sub_447f60(1, 0x8130, nullptr, 0x4cf1a4)
sub_447f60(1, 0x8150, nullptr, nullptr, data_4cf1a8)
sub_447f60(1, 0x8130, 1, 0x4cf190)
sub_447f60(1, 0x8150, 1, nullptr, data_4cf194)
sub_447f60(1, 0x8010, 0x980, 0x3fff)
sub_447f60(1, 0x8010, 0xa80, 0x3fff)
sub_447f60(1, 0x8010, 0x981, 0x3fff)
sub_447f60(1, 0x8010, 0xa81, 0x3fff)
return 1
