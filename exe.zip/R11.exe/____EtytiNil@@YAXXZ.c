// 函数: ??__EtytiNil@@YAXXZ
// 地址: 0x401570
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_2b60340 = 0
__builtin_memset(&data_2b60350, 0, 0x14)
data_2b60364 = 0x7d0
return sub_4013b0() __tailcall
