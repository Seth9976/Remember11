// 函数: sub_4073a0
// 地址: 0x4073a0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

*(arg1 + 0x7e4c) = 0xffffffff
char* result = sub_481240(arg1 + 0xc0, "Content-Length:")

if (result != 0)
    result = j_sub_4812c6(&result[0xf])
    *(arg1 + 0x7e4c) = result

return result
