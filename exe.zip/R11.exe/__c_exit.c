// 函数: __c_exit
// 地址: 0x482d00
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return sub_482bed(0, 1, 1)
