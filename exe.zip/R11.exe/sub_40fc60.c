// 函数: sub_40fc60
// 地址: 0x40fc60
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax_4 = data_e7e648
*(eax_4 + 0x20838) = 0
*(eax_4 + 0x20860) = 0
*(eax_4 + 0x20844) = 0
int32_t* eax_2 = data_e7e648 + 0x20888
*eax_2 = 0
eax_2[0xa].b = 0
eax_2[3] = 0
int32_t* result = data_e7e648 + 0x208d8
*result = 0
result[0xa].b = 0
result[3] = 0
return result
