// 函数: sub_4089d0
// 地址: 0x4089d0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t edx = data_8969d4
int32_t __saved_esi = 0
void* var_20 = ((*(arg1 + 8) + 1) << 4) + arg1
int32_t var_1c = edx
int32_t var_18 = 0x1000
int32_t var_14 = 0
sub_448170(&var_20, 1)
int32_t var_28_1 = 1
return 0xffffffff
