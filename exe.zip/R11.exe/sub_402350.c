// 函数: sub_402350
// 地址: 0x402350
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_4cd170 = 0
data_4cd174 = 0
data_4cd178 = arg1
data_4cd180 = arg1 * 0xf s/ 0x140
data_4cd188 = arg1 * 0x18 s/ 0x140
int32_t result = arg2 * 0x18 s/ 0xf0
data_4cd17c = arg2
data_4cd184 = arg2
data_4cd18c = result
return result
