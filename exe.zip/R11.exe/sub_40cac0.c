// 函数: sub_40cac0
// 地址: 0x40cac0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax_1 = *(arg1[0x11] + 8)
sub_416990(zx.d(*(eax_1 + 1)), (*(eax_1 + 2)).b)
void* eax_2 = arg1[0x11]
*(eax_2 + 8) += 4
sub_40a8a0(arg1)
return 0
