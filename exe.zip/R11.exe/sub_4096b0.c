// 函数: sub_4096b0
// 地址: 0x4096b0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax_1 = sub_405c60(sub_405e30(4, arg1, 0, arg2))
sub_448310(arg1)

if (data_a5958f != 0)
    data_8969a8 = sub_4072c0(0x8020, 0)
    data_8969ac = sub_4072c0(0x8161, 0)

data_a5958f = 0
sub_408cd0(eax_1)
int32_t var_10 = arg3
return sub_4095f0()
