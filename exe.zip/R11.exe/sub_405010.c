// 函数: sub_405010
// 地址: 0x405010
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

*(arg1 + 4) = 0x1e
arg1[2] = 0
arg1[0x14] = 0
arg1[0x18] = 0x80
arg1[0x17] = 0
arg1[0x16] = 0
arg1[0x15] = 0
*(arg1 + 0xc) = 0
*arg1 = 0
arg1[1] = 0
*(arg1 + 8) = 0
*(arg1 + 0x10) = 0
*(arg1 + 0x2c) = 0
*(arg1 + 0x60) = arg1
*(arg1 + 0x1c) = data_4af580
return arg1
