// 函数: ov_read
// 地址: 0x4985a0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return ov_read() __tailcall
