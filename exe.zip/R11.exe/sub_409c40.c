// 函数: sub_409c40
// 地址: 0x409c40
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t var_10 = 0
int32_t var_c = 0
int32_t var_8 = 0x280
int32_t var_4 = 0x1c0
return sub_442670(&var_10, arg1)
