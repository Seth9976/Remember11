// 函数: sub_409230
// 地址: 0x409230
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

data_8969e8 = data_2b603ac
data_8969f0 = 0
data_8969ec = 0
return 0
