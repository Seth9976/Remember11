// 函数: ?unexpected@@YAXXZ
// 地址: 0x48b1cb
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

int32_t eax = *(__getptd() + 0x7c)

if (eax != 0)
    eax()

noreturn terminate() __tailcall
