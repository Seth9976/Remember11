// 函数: sub_406780
// 地址: 0x406780
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* result = arg1 * 6

if (data_2b5cf14 == 0 && arg2 != 0)
    *(result + &data_2b53760) = 1
    *(result + 0x2b53761) = arg2.b
    return result

*(result + 0x2b53761) = 0
*(result + &data_2b53760) = 0
return result
