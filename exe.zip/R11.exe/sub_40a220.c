// 函数: sub_40a220
// 地址: 0x40a220
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax_3 = data_e7e648
sub_405e30(7, 5, *(eax_3 + 0xbf0c0), *(eax_3 + 0xbf0c4))
void* eax = data_e7e648
return sub_4427e0(eax + 0x10f2f0, 0x900, 0, *(eax + 0xbf0c0))
