// 函数: _vsnprintf_s
// 地址: 0x48318c
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return sub_483085(arg1, arg2, arg3, arg4, 0, arg5)
