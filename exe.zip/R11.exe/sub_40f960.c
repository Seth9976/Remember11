// 函数: sub_40f960
// 地址: 0x40f960
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* result = data_e7e648
*(result + 0xb4464) = 0
return result
