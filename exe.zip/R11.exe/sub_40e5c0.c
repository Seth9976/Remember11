// 函数: sub_40e5c0
// 地址: 0x40e5c0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* eax = arg1[0x11]
*(eax + 8) += 2
sub_40a8a0(arg1)
return 0
