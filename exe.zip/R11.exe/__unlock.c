// 函数: __unlock
// 地址: 0x4866a5
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return LeaveCriticalSection(*((arg1 << 3) + &data_4cbf58))
