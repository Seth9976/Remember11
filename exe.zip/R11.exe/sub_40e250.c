// 函数: sub_40e250
// 地址: 0x40e250
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

*(data_e7e648 + 0x28c1) = *(*(arg1[0x11] + 8) + 1)
sub_415550()
void* eax_2 = arg1[0x11]
*(eax_2 + 8) += 2
sub_40a8a0(arg1)
return 0
