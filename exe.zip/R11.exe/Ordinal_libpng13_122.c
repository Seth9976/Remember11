// 函数: Ordinal_libpng13_122
// 地址: 0x498564
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return Ordinal_libpng13_122() __tailcall
