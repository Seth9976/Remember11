// 函数: __allmul
// 地址: 0x480aa0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

if ((arg4 | arg2) == 0)
    return arg1 * arg3

int32_t result
int32_t edx
edx:result = mulu.dp.d(arg1, arg3)
return result
