// 函数: __ehhandler$??_U@YAPAXIW4align_val_t@std@@ABUnothrow_t@1@@Z
// 地址: 0x499820
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

sub_480cd2(*(arg1 - 0x1c) ^ (arg1 + 0xc))
return sub_48212c(0x4aa62c) __tailcall
