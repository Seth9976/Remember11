// 函数: sub_402240
// 地址: 0x402240
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

switch (arg1)
    case 0
        return zx.d(data_2b5cf02)
    case 1
        return zx.d(data_2b5cf03)
    case 2
        return zx.d(data_2b5cf04)
    case 3
        return zx.d(data_2b5cf05)

return 0x80
