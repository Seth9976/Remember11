// 函数: sub_40c350
// 地址: 0x40c350
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* edi = *(arg1[0x11] + 8)
int32_t i = 0

if (*(edi + 1) u> 0)
    do
        sub_41e250(&data_49ea48, 1, 0, 0xffff, 0)
        i += 1
    while (i s< zx.d(*(edi + 1)))

void* eax_1 = arg1[0x11]
*(eax_1 + 8) += 2
sub_40a8a0(arg1)
return 0
