// 函数: ov_open_callbacks
// 地址: 0x49859a
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

return ov_open_callbacks() __tailcall
