// 函数: sub_40e1f0
// 地址: 0x40e1f0
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

void* ecx
ecx.b = *(*(arg1[0x11] + 8) + 1)
*(data_e7e648 + 0x28c4) = ecx.b
void* ecx_1 = arg1[0x11]
*(ecx_1 + 8) += 2
sub_40a8a0(arg1)
return 0
