// 函数: sub_406b80
// 地址: 0x406b80
// 来自: E:/torrent/Apollo/R11/R11.exe.bndb

char const* const var_10 = "----user init start----\n"
char const* const var_14 = "work init\n"
data_2b55e68 = 0
data_2b55e64 = 0
data_2b55e60 = 0
data_2b603ac = 0
char const* const var_18 = "pad init\n"
data_2b603a0 = 1
data_2b60388 = 0
data_2b60384 = 0
data_2b60380 = 0
data_2b60370 = 0
data_2b6036c = 0
data_2b55e74 = 0
data_2b60368 = 0
data_2b55e70 = 0
sub_4420e0(&data_2b53780, 0x2b53600, 2)
sub_4420c0(0x14, 0x14, 2)
sub_441f40(0, 0)
sub_441f40(1, 0x10)
char const* const var_44 = "task init\n"
sub_446ba0(0x2b53860, 0x80, 1)
char const* const var_10_1 = "spr init\n"
sub_442570(&data_2b53380, 8, &data_2b53080, 0x10)
data_c7bbd0 = 0x6c00
data_c7bbd4 = 0x7200
sub_442630(0, 0x2b51a80, 0x80)
int32_t edi = 1

for (int32_t i = 0x2b51ef8; i s< 0x2b53238; )
    sub_442630(edi, i, 0x10)
    i += 0x2c0
    edi += 1

for (int32_t i_1 = 0; i_1 s< 0x1b8; i_1 += 0x2c)
    sub_442750(*data_c7bbc0 + i_1, 0xffffffff, 0x900, 0, 0, 0, 0, 0, 0, 0x20, 0x20, 0, 0)

sub_442750(*data_c7bbc0, 0x207e680, 0, 0, 0, 0, 0, 0, 0, 0x280, 0x1c0, 0, 0)
sub_442750(*data_c7bbc0 + 0x2c, 0x207e680, 0x20, 0, 0, 0, 0, 0, 0, 0x280, 0x1c0, 0, 0)
sub_442750(*data_c7bbc0 + 0x58, 0x207e680, 0x900, 0, 0, 0, 0, 0, 0, 0x280, 0x1c0, 0, 0)
char const* const var_44_1 = "file init\n"
sub_4417f0(&data_2b533c0, 0x10)
char const* const var_10_2 = "fnt init\n"
sub_441d00(0x2b4fb80, 0x40)
char const* const var_1c = "debug init\n"
j_sub_4413a0()
char const* const var_20 = "clock init\n"
tytiNil::()
char const* const var_24 = "fade init\n"
sub_405050()
sub_402350(0x280, 0x1c0)
char const* const var_30 = "raster init\n"
sub_407960()
char const* const var_34 = "vblk init\n"
sub_409b00()
char const* const var_38 = "sse init\n"
sub_408c00()
char const* const var_3c = "bgm init\n"
sub_408cb0()
char const* const var_40_4 = "adx init\n"
sub_408fa0()
sub_408ff0(0, 6, 2)
sub_408ff0(2, 5, 1)
sub_408ff0(1, 5, 0)
sub_408ff0(3, 5, 1)
sub_408ff0(4, 5, 1)
sub_408ff0(5, 5, 1)
char const* const var_4c = "bar init\n"
sub_401000()
char const* const var_10_3 = "draw init\n"
sub_43f410()
char const* const var_14_2 = "----user init end----\n"
data_2243af8 = 0
data_2243af0 = 1
data_2243af1 = 1
data_2243af2 = 1
data_2243af3 = 1
data_2243af4 = 1
data_2243af5 = 1
data_2243af6 = 1
data_2243af7 = 1
data_2243af9 = 1
return sub_407b50() __tailcall
